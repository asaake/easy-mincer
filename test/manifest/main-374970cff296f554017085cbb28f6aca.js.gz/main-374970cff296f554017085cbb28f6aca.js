var Main;

Main = (function() {
  function Main() {}

  return Main;

})();